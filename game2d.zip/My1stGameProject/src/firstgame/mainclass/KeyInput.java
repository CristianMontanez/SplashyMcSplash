package firstgame.mainclass;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class KeyInput extends KeyAdapter {
	
	private Handler handler; // creating instnace of our Handler class
	
	public KeyInput (Handler handler) 
	{
		this.handler = handler ; // lets us input handler into key input class 
	}
	
	
	public void keyPressed(KeyEvent e ) 
	{
		int key = e.getKeyCode(); // getKeyCode reterives the key number value with the specific key that is pressed. 
		
		for(int i =0; i < handler.object.size(); i++) // goes through our handlr objects and chooses which character to move. 
		{
			GameObject tempObject = handler.object.get(i);
			
			if (tempObject.getID() == ID.Player ) // traverses the for loop till player 1 (us ) is reached for key events. 
			{
				// this is where all the key events will be for player 1  , the for loop helps out code choose which object to control .
				
				// at this moment temObject becomes ID.Player 
				
				if(key == KeyEvent.VK_W) tempObject.setVelY(-5);// allows our player 1 character to go up
				if(key == KeyEvent.VK_S) tempObject.setVelY(5); // + makes our char go down - makes our char go up 
				if(key == KeyEvent.VK_D) tempObject.setVelX(5); // Y is vertical (up & down) X is horizontal side to side 
				if(key == KeyEvent.VK_A) tempObject.setVelX(-5);
			}
			
			
		}
		
		
	}
	
	public void keyReleased(KeyEvent e) 
	{
		int key = e.getKeyCode();
		
		for(int i =0; i < handler.object.size(); i++) 
		{
			GameObject tempObject = handler.object.get(i);
			
			if (tempObject.getID() == ID.Player ) 
			{
				
				if(key == KeyEvent.VK_W) tempObject.setVelY(0);// setting to 0 will make the player stop
				if(key == KeyEvent.VK_S) tempObject.setVelY(0); 
				if(key == KeyEvent.VK_D) tempObject.setVelX(0); 
				if(key == KeyEvent.VK_A) tempObject.setVelX(0);
			}
			
			
		}
	}

}
