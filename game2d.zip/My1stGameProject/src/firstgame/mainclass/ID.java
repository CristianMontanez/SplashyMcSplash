package firstgame.mainclass;

public enum ID {
	
	Player() ,// we can make a ID for our player
	BasicEnemy(); // make a id for our enemy. 

}
