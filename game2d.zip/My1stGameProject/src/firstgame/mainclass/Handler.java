package firstgame.mainclass;

import java.awt.Graphics;
import java.util.LinkedList;

// This class is used to list all of our game objects we have in our game .

// this handler class goes through all of our objects in game , rendering them and updateing them. 
public class Handler {
	
	LinkedList<GameObject> object = new LinkedList <GameObject>();
	
	public void tick() 
	{
		for (int i = 0; i < object.size(); i++) // this  for loop will go through all of our objects in our game 
		{
		 GameObject tempObject = object.get(i); // sets our tempObject varible to i , gets ID of where we are at /.
		 
		 tempObject.tick();
		}
		
	}
	
	public void render(Graphics G) // loops through all of our game object and renders all of our game objects.
	{
		
		for(int i = 0 ; i < object.size(); i++) 
		{
			GameObject tempObject = object.get(i);
			
			tempObject.render(G);
		}
		
	}
	
	public void addObject ( GameObject object) // allows us to add objects to our list 
	{
		this.object.add(object);
	}
	
	public void removeObject (GameObject object) // allows us to remove object from our LinkedList .
	{
		this.object.remove(object);
	}

}
