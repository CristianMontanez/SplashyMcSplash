package firstgame.mainclass;

import java.awt.Color;
import java.awt.Graphics;

public class Player extends GameObject {

	public Player(int x, int y, ID id) {
		super(x, y, id);
		
	

		
	}

	public void tick() {
		
		x += velX; // Makes our in game objects move. 
		
		y+= velY;
		
		if(y <= 0 || y>= Game.HEIGHT - 32) y*= 0;
		if(x <= 0 || x>= Game.WIDTH - 16) x*= 0;
		
	}

	
	public void render(Graphics g) {
		
		g.setColor(Color.white);
		g.fillRect(x, y, 32, 32);
		
	}

}
