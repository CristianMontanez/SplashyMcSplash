package firstgame.mainclass;

import java.awt.Canvas;
import java.awt.Dimension;

import javax.swing.JFrame;

public class Window extends Canvas 


{
	
	
	private static final long serialVersionUID = -2708712492386560868L;
	


	public Window (int width, int height,String title,Game game) 
	{
		JFrame frame = new JFrame(title); // Makes the window for our game , class in JAVA library 
		
		frame.setPreferredSize(new Dimension (width,height )); // all these function references is to make our window for the game set parameters for sizes. 
		frame.setMaximumSize(new Dimension (width,height ));
		frame.setMinimumSize(new Dimension (width,height ));
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // think of this the 'X' button on any operation to actually work
		frame.setResizable(false); // can we resize our window? false does not let us 
		frame.setLocationRelativeTo(null);// Makes our frame start in the middle of our screen. 
		frame.add(game);// adding our "Game" class onto our window/Frame 
		frame.setVisible(true); // so we can see the window . 
		game.start();// running start method we created in game class 
		
	}

}


