package firstgame.mainclass;

import java.awt.Color;
import java.awt.Graphics;

public class BasicEnemy extends GameObject  {

	public BasicEnemy(int x, int y, ID id) {
		super(x, y, id);
		
		velX = 5;
		velY = 5 ; 
		
	}

	
	public void tick() {
		x += velX;
		y += velY; 
		
		if(y <= 0 || y >= Game.HEIGHT - 32) velY *= -1; // when the game object hits bottom or top of screen , the * -1 reverses the velY (Eg. 5 * 1 = -5 )   
		if(x <= 0 || x >= Game.WIDTH - 16) velX *= -1; // same as what is described above but for X value (side 2 side) 
	}


	public void render(Graphics g) {
		g.setColor(Color.DARK_GRAY);
		g.fillRect(x, y, 16, 16);
		
	}

}
